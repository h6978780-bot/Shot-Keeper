package com.shotkeeper.app

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx = app.applicationContext
    private val dao = AppDatabase.get(ctx).dao()

    val folders: StateFlow<List<Folder>> =
        dao.folders().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val filterImportance = MutableStateFlow<Int?>(null)
    val filterFolder = MutableStateFlow<Long?>(null)

    val shots: StateFlow<List<Shot>> =
        combine(dao.shots(), filterImportance, filterFolder) { all, imp, fol ->
            all.filter { (imp == null || it.importance == imp) && (fol == null || it.folderId == fol) }
                .sortedWith(compareByDescending<Shot> { it.importance }.thenByDescending { it.addedAt })
        }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    // طابور اللقطات اللي لسا ما انصنّفت (أو اللقطة المفتوحة حالياً)
    val queue = MutableStateFlow<List<Long>>(emptyList())
    val importMode = MutableStateFlow(false)

    @OptIn(ExperimentalCoroutinesApi::class)
    val current: StateFlow<Shot?> = queue.flatMapLatest { q ->
        if (q.isEmpty()) flowOf<Shot?>(null) else dao.shotFlow(q.first())
    }.stateIn(viewModelScope, SharingStarted.Eagerly, null)

    fun importUris(uris: List<Uri>) {
        viewModelScope.launch {
            val ids = mutableListOf<Long>()
            for (u in uris) {
                try {
                    ctx.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (_: Exception) {
                }
                if (dao.countUri(u.toString()) == 0) {
                    ids += dao.insert(Shot(uri = u.toString()))
                }
            }
            if (ids.isNotEmpty()) {
                importMode.value = true
                queue.value = ids
            }
        }
    }

    fun open(id: Long) {
        importMode.value = false
        queue.value = listOf(id)
    }

    fun next() {
        queue.value = queue.value.drop(1)
        if (queue.value.isEmpty()) importMode.value = false
    }

    /** remindDays: -1 = بدون تغيير، 0 = إلغاء التذكير، غير هيك = عدد الأيام */
    fun save(id: Long, importance: Int, folderId: Long?, remindDays: Int) {
        viewModelScope.launch {
            val s = dao.get(id)
            if (s != null) {
                var remindAt = s.remindAt
                if (remindDays == 0) {
                    remindAt = null
                    Reminders.cancel(ctx, id)
                } else if (remindDays > 0) {
                    val delay = remindDays * 24L * 60L * 60L * 1000L
                    remindAt = System.currentTimeMillis() + delay
                    Reminders.schedule(ctx, id, delay)
                }
                dao.update(s.copy(importance = importance, folderId = folderId, remindAt = remindAt))
            }
            next()
        }
    }

    fun delete(shot: Shot) {
        viewModelScope.launch {
            Reminders.cancel(ctx, shot.id)
            dao.delete(shot)
            next()
        }
    }

    fun addFolder(name: String) {
        viewModelScope.launch { dao.insertFolder(Folder(name = name.trim())) }
    }

    fun deleteFolder(id: Long) {
        viewModelScope.launch {
            dao.clearFolder(id)
            dao.deleteFolder(id)
            if (filterFolder.value == id) filterFolder.value = null
        }
    }
}
