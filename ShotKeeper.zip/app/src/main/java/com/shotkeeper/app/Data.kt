package com.shotkeeper.app

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "shots")
data class Shot(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val uri: String,
    val importance: Int = 0, // 0 = غير مصنّفة, 1 = منخفضة, 2 = متوسطة, 3 = عالية
    val folderId: Long? = null,
    val remindAt: Long? = null,
    val addedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "folders")
data class Folder(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String
)

@Dao
interface ShotDao {
    @Query("SELECT * FROM shots")
    fun shots(): Flow<List<Shot>>

    @Query("SELECT * FROM shots WHERE id = :id")
    fun shotFlow(id: Long): Flow<Shot?>

    @Query("SELECT * FROM shots WHERE id = :id")
    suspend fun get(id: Long): Shot?

    @Query("SELECT COUNT(*) FROM shots WHERE uri = :uri")
    suspend fun countUri(uri: String): Int

    @Insert
    suspend fun insert(shot: Shot): Long

    @Update
    suspend fun update(shot: Shot)

    @Delete
    suspend fun delete(shot: Shot)

    @Query("SELECT * FROM folders ORDER BY name")
    fun folders(): Flow<List<Folder>>

    @Insert
    suspend fun insertFolder(folder: Folder): Long

    @Query("DELETE FROM folders WHERE id = :id")
    suspend fun deleteFolder(id: Long)

    @Query("UPDATE shots SET folderId = NULL WHERE folderId = :id")
    suspend fun clearFolder(id: Long)
}

@Database(entities = [Shot::class, Folder::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): ShotDao

    companion object {
        @Volatile
        private var inst: AppDatabase? = null

        fun get(ctx: Context): AppDatabase = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(
                ctx.applicationContext, AppDatabase::class.java, "shotkeeper.db"
            ).build().also { inst = it }
        }
    }
}
