@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.shotkeeper.app

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun impLabel(i: Int) = when (i) {
    3 -> "عالية"
    2 -> "متوسطة"
    1 -> "منخفضة"
    else -> "غير مصنّفة"
}

fun impColor(i: Int) = when (i) {
    3 -> Color(0xFFE53935)
    2 -> Color(0xFFFB8C00)
    1 -> Color(0xFF43A047)
    else -> Color(0xFF9E9E9E)
}

fun fmtTime(t: Long): String = SimpleDateFormat("d/M  HH:mm", Locale.getDefault()).format(Date(t))

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null) handle(intent)
        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    AppScreen(vm)
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handle(intent)
    }

    private fun handle(i: Intent?) {
        val id = i?.getLongExtra("shot_id", -1L) ?: -1L
        if (id > 0) vm.open(id)
    }
}

@Composable
fun AppScreen(vm: MainViewModel) {
    val shots by vm.shots.collectAsState()
    val folders by vm.folders.collectAsState()
    val fImp by vm.filterImportance.collectAsState()
    val fFolder by vm.filterFolder.collectAsState()
    val current by vm.current.collectAsState()
    val importMode by vm.importMode.collectAsState()
    var showNewFolder by remember { mutableStateOf(false) }

    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) vm.importUris(uris)
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("ShotKeeper") }) },
        floatingActionButton = {
            FloatingActionButton(onClick = { picker.launch(arrayOf("image/*")) }) {
                Icon(Icons.Default.Add, contentDescription = "إضافة لقطات")
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad)) {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    FilterChip(selected = fImp == null, onClick = { vm.filterImportance.value = null },
                        label = { Text("الكل") })
                }
                items(listOf(3, 2, 1, 0)) { i ->
                    FilterChip(selected = fImp == i, onClick = { vm.filterImportance.value = i },
                        label = { Text(impLabel(i)) })
                }
            }
            LazyRow(
                contentPadding = PaddingValues(horizontal = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    FilterChip(selected = fFolder == null, onClick = { vm.filterFolder.value = null },
                        label = { Text("كل المجلدات") })
                }
                items(folders) { f ->
                    FilterChip(selected = fFolder == f.id, onClick = { vm.filterFolder.value = f.id },
                        label = { Text("📁 " + f.name) })
                }
                item {
                    AssistChip(onClick = { showNewFolder = true }, label = { Text("＋ مجلد جديد") })
                }
            }
            fFolder?.let { id ->
                TextButton(onClick = { vm.deleteFolder(id) }) { Text("حذف المجلد المحدد") }
            }

            if (shots.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("ما في لقطات هون.\nاضغط ＋ لإضافة لقطات شاشة.")
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(shots, key = { it.id }) { s ->
                        ShotRow(s, folders.firstOrNull { it.id == s.folderId }?.name) { vm.open(s.id) }
                    }
                }
            }
        }
    }

    if (showNewFolder) {
        var name by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showNewFolder = false },
            title = { Text("مجلد جديد") },
            text = {
                OutlinedTextField(value = name, onValueChange = { name = it },
                    singleLine = true, label = { Text("اسم المجلد") })
            },
            confirmButton = {
                Button(onClick = {
                    if (name.isNotBlank()) vm.addFolder(name)
                    showNewFolder = false
                }) { Text("إضافة") }
            },
            dismissButton = { TextButton(onClick = { showNewFolder = false }) { Text("إلغاء") } }
        )
    }

    current?.let { shot ->
        EditorDialog(
            shot = shot,
            folders = folders,
            importMode = importMode,
            onSave = { imp, folder, remind -> vm.save(shot.id, imp, folder, remind) },
            onSkip = { vm.next() },
            onDelete = { vm.delete(shot) }
        )
    }
}

@Composable
fun ShotRow(shot: Shot, folderName: String?, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            AsyncImage(
                model = shot.uri,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.size(84.dp).clip(RoundedCornerShape(8.dp))
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(12.dp).clip(CircleShape).background(impColor(shot.importance)))
                    Spacer(Modifier.width(6.dp))
                    Text(impLabel(shot.importance), fontWeight = FontWeight.Bold)
                }
                folderName?.let { Text("📁 $it") }
                shot.remindAt?.let { Text("⏰ " + fmtTime(it)) }
            }
        }
    }
}

@Composable
fun EditorDialog(
    shot: Shot,
    folders: List<Folder>,
    importMode: Boolean,
    onSave: (Int, Long?, Int) -> Unit,
    onSkip: () -> Unit,
    onDelete: () -> Unit
) {
    var imp by remember(shot.id) { mutableIntStateOf(shot.importance) }
    var folder by remember(shot.id) { mutableStateOf(shot.folderId) }
    var remind by remember(shot.id) { mutableIntStateOf(-1) }
    val remindOptions = listOf(
        0 to "بدون تذكير", 1 to "بعد يوم", 2 to "بعد يومين", 3 to "بعد 3 أيام",
        7 to "بعد أسبوع", 14 to "بعد أسبوعين", 30 to "بعد شهر"
    )

    AlertDialog(
        onDismissRequest = onSkip,
        title = { Text(if (importMode) "صنّف اللقطة" else "تفاصيل اللقطة") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                AsyncImage(
                    model = shot.uri,
                    contentDescription = null,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxWidth().height(260.dp)
                )
                Spacer(Modifier.height(12.dp))
                Text("الأهمية", style = MaterialTheme.typography.labelLarge)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(3, 2, 1, 0).forEach { i ->
                        FilterChip(selected = imp == i, onClick = { imp = i }, label = { Text(impLabel(i)) })
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text("المجلد", style = MaterialTheme.typography.labelLarge)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = folder == null, onClick = { folder = null }, label = { Text("بدون مجلد") })
                    folders.forEach { f ->
                        FilterChip(selected = folder == f.id, onClick = { folder = f.id },
                            label = { Text(f.name) })
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text("التذكير", style = MaterialTheme.typography.labelLarge)
                if (remind == -1 && shot.remindAt != null) {
                    Text("التذكير الحالي: " + fmtTime(shot.remindAt))
                }
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    remindOptions.forEach { (d, label) ->
                        FilterChip(selected = remind == d, onClick = { remind = d }, label = { Text(label) })
                    }
                }
                Spacer(Modifier.height(8.dp))
                TextButton(
                    onClick = onDelete,
                    colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                ) {
                    Icon(Icons.Default.Delete, contentDescription = null)
                    Spacer(Modifier.width(4.dp))
                    Text("حذف اللقطة")
                }
            }
        },
        confirmButton = { Button(onClick = { onSave(imp, folder, remind) }) { Text("حفظ") } },
        dismissButton = { TextButton(onClick = onSkip) { Text(if (importMode) "تخطّي" else "إغلاق") } }
    )
}
