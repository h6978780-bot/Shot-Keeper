package com.shotkeeper.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.work.*
import java.util.concurrent.TimeUnit

object Reminders {
    private const val CHANNEL = "reminders"

    fun schedule(ctx: Context, shotId: Long, delayMs: Long) {
        val req = OneTimeWorkRequestBuilder<ReminderWorker>()
            .setInitialDelay(delayMs, TimeUnit.MILLISECONDS)
            .setInputData(workDataOf("id" to shotId))
            .build()
        WorkManager.getInstance(ctx)
            .enqueueUniqueWork("remind_$shotId", ExistingWorkPolicy.REPLACE, req)
    }

    fun cancel(ctx: Context, shotId: Long) {
        WorkManager.getInstance(ctx).cancelUniqueWork("remind_$shotId")
    }

    fun notify(ctx: Context, shot: Shot) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "التذكيرات", NotificationManager.IMPORTANCE_DEFAULT)
        )
        val intent = Intent(ctx, MainActivity::class.java)
            .putExtra("shot_id", shot.id)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pi = PendingIntent.getActivity(
            ctx, shot.id.toInt(), intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("ShotKeeper ⏰")
            .setContentText("ارجع شوف لقطة حفظتها (أهمية: ${impLabel(shot.importance)})")
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        nm.notify(shot.id.toInt(), n)
    }
}

class ReminderWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val id = inputData.getLong("id", -1L)
        val dao = AppDatabase.get(applicationContext).dao()
        val shot = dao.get(id) ?: return Result.success()
        if (shot.remindAt == null) return Result.success()
        Reminders.notify(applicationContext, shot)
        dao.update(shot.copy(remindAt = null))
        return Result.success()
    }
}
